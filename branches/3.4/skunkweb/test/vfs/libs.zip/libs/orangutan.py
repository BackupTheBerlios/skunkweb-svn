FOO="this is orangatan.FOO"

from droppings import FOO as f

FOO=f+": NOT!!!"

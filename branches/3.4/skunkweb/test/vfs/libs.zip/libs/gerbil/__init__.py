from droppings import *

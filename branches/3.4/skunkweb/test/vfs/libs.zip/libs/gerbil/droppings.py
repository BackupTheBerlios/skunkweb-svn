FOO="this is gerbil.droppings.FOO"

FOO="this is hamster.droppings.FOO"
